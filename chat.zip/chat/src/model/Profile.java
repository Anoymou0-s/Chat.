package model;

public class Profile {
    private int id;
    private String fullName;
    private int age;
    private String school;
    private String college;
    private String academicQualification;
    private String degree;
    private String fieldOfSpecialization;
    private String academicInterests;
    private String professionalInterests;
    private String hobbies;
    private String city;
    private String languages;
    private String workExperience;
    private String careerAspirations;
    private String extracurricularActivities;
    private String conversationProfile;

    // Getters and setters for all fields
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public String getSchool() { return school; }
    public void setSchool(String school) { this.school = school; }
    public String getCollege() { return college; }
    public void setCollege(String college) { this.college = college; }
    public String getAcademicQualification() { return academicQualification; }
    public void setAcademicQualification(String academicQualification) { this.academicQualification = academicQualification; }
    public String getDegree() { return degree; }
    public void setDegree(String degree) { this.degree = degree; }
    public String getFieldOfSpecialization() { return fieldOfSpecialization; }
    public void setFieldOfSpecialization(String fieldOfSpecialization) { this.fieldOfSpecialization = fieldOfSpecialization; }
    public String getAcademicInterests() { return academicInterests; }
    public void setAcademicInterests(String academicInterests) { this.academicInterests = academicInterests; }
    public String getProfessionalInterests() { return professionalInterests; }
    public void setProfessionalInterests(String professionalInterests) { this.professionalInterests = professionalInterests; }
    public String getHobbies() { return hobbies; }
    public void setHobbies(String hobbies) { this.hobbies = hobbies; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public String getLanguages() { return languages; }
    public void setLanguages(String languages) { this.languages = languages; }
    public String getWorkExperience() { return workExperience; }
    public void setWorkExperience(String workExperience) { this.workExperience = workExperience; }
    public String getCareerAspirations() { return careerAspirations; }
    public void setCareerAspirations(String careerAspirations) { this.careerAspirations = careerAspirations; }
    public String getExtracurricularActivities() { return extracurricularActivities; }
    public void setExtracurricularActivities(String extracurricularActivities) { this.extracurricularActivities = extracurricularActivities; }
    public String getConversationProfile() { return conversationProfile; }
    public void setConversationProfile(String conversationProfile) { this.conversationProfile = conversationProfile; }
}
