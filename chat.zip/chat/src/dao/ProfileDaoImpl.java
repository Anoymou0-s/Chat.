package dao;

import model.Profile;
import java.sql.*;
import java.util.*;

public class ProfileDaoImpl implements ProfileDao {
    private Connection conn;

    public ProfileDaoImpl(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void addProfile(Profile profile) {
        String sql = "INSERT INTO profile (full_name, age, school, college, academic_qualification, degree, field_of_specialization, academic_interests, professional_interests, hobbies, city, languages, work_experience, career_aspirations, extracurricular_activities, conversation_profile) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, profile.getFullName());
            stmt.setInt(2, profile.getAge());
            stmt.setString(3, profile.getSchool());
            stmt.setString(4, profile.getCollege());
            stmt.setString(5, profile.getAcademicQualification());
            stmt.setString(6, profile.getDegree());
            stmt.setString(7, profile.getFieldOfSpecialization());
            stmt.setString(8, profile.getAcademicInterests());
            stmt.setString(9, profile.getProfessionalInterests());
            stmt.setString(10, profile.getHobbies());
            stmt.setString(11, profile.getCity());
            stmt.setString(12, profile.getLanguages());
            stmt.setString(13, profile.getWorkExperience());
            stmt.setString(14, profile.getCareerAspirations());
            stmt.setString(15, profile.getExtracurricularActivities());
            stmt.setString(16, profile.getConversationProfile());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateProfile(Profile profile) {
        String sql = "UPDATE profile SET full_name=?, age=?, school=?, college=?, academic_qualification=?, degree=?, field_of_specialization=?, academic_interests=?, professional_interests=?, hobbies=?, city=?, languages=?, work_experience=?, career_aspirations=?, extracurricular_activities=?, conversation_profile=? WHERE id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, profile.getFullName());
            stmt.setInt(2, profile.getAge());
            stmt.setString(3, profile.getSchool());
            stmt.setString(4, profile.getCollege());
            stmt.setString(5, profile.getAcademicQualification());
            stmt.setString(6, profile.getDegree());
            stmt.setString(7, profile.getFieldOfSpecialization());
            stmt.setString(8, profile.getAcademicInterests());
            stmt.setString(9, profile.getProfessionalInterests());
            stmt.setString(10, profile.getHobbies());
            stmt.setString(11, profile.getCity());
            stmt.setString(12, profile.getLanguages());
            stmt.setString(13, profile.getWorkExperience());
            stmt.setString(14, profile.getCareerAspirations());
            stmt.setString(15, profile.getExtracurricularActivities());
            stmt.setString(16, profile.getConversationProfile());
            stmt.setInt(17, profile.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteProfile(int id) {
        String sql = "DELETE FROM profile WHERE id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Profile getProfile(int id) {
        String sql = "SELECT * FROM profile WHERE id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractProfile(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Profile> getAllProfiles() {
        List<Profile> profiles = new ArrayList<>();
        String sql = "SELECT * FROM profile";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                profiles.add(extractProfile(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return profiles;
    }

    private Profile extractProfile(ResultSet rs) throws SQLException {
        Profile profile = new Profile();
        profile.setId(rs.getInt("id"));
        profile.setFullName(rs.getString("full_name"));
        profile.setAge(rs.getInt("age"));
        profile.setSchool(rs.getString("school"));
        profile.setCollege(rs.getString("college"));
        profile.setAcademicQualification(rs.getString("academic_qualification"));
        profile.setDegree(rs.getString("degree"));
        profile.setFieldOfSpecialization(rs.getString("field_of_specialization"));
        profile.setAcademicInterests(rs.getString("academic_interests"));
        profile.setProfessionalInterests(rs.getString("professional_interests"));
        profile.setHobbies(rs.getString("hobbies"));
        profile.setCity(rs.getString("city"));
        profile.setLanguages(rs.getString("languages"));
        profile.setWorkExperience(rs.getString("work_experience"));
        profile.setCareerAspirations(rs.getString("career_aspirations"));
        profile.setExtracurricularActivities(rs.getString("extracurricular_activities"));
        profile.setConversationProfile(rs.getString("conversation_profile"));
        return profile;
    }
}
