package dao;

import model.Profile;
import java.util.List;

public interface ProfileDao {
    void addProfile(Profile profile);
    void updateProfile(Profile profile);
    void deleteProfile(int id);
    Profile getProfile(int id);
    List<Profile> getAllProfiles();
}
