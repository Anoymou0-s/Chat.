package service;

import dao.ProfileDao;
import model.Profile;
import java.util.List;

public class ProfileService {
    private ProfileDao profileDao;

    public ProfileService(ProfileDao profileDao) {
        this.profileDao = profileDao;
    }

    public void addProfile(Profile profile) {
        profileDao.addProfile(profile);
    }

    public void updateProfile(Profile profile) {
        profileDao.updateProfile(profile);
    }

    public void deleteProfile(int id) {
        profileDao.deleteProfile(id);
    }

    public Profile getProfile(int id) {
        return profileDao.getProfile(id);
    }

    public List<Profile> getAllProfiles() {
        return profileDao.getAllProfiles();
    }
}
