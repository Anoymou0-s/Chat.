package ui;

import model.Profile;
import javax.swing.*;
import java.awt.*;

public class ProfileDialog extends JDialog {
    private boolean saved = false;
    private Profile profile;
    private JTextField[] fields = new JTextField[17];
    private String[] labels = {
        "Full Name", "Age", "School", "College", "Academic Qualification", "Degree", "Specialization", "Academic Interests", "Professional Interests", "Hobbies", "City", "Languages", "Work Experience", "Career Aspirations", "Extracurricular Activities", "Conversation Profile"
    };

    public ProfileDialog(Frame owner, Profile profile) {
        super(owner, true);
        setTitle(profile == null ? "Add Profile" : "Edit Profile");
        setSize(400, 600);
        setLayout(new BorderLayout());
        JPanel form = new JPanel(new GridLayout(labels.length, 2));
        for (int i = 0; i < labels.length; i++) {
            form.add(new JLabel(labels[i]));
            fields[i] = new JTextField();
            form.add(fields[i]);
        }
        if (profile != null) {
            fields[0].setText(profile.getFullName());
            fields[1].setText(String.valueOf(profile.getAge()));
            fields[2].setText(profile.getSchool());
            fields[3].setText(profile.getCollege());
            fields[4].setText(profile.getAcademicQualification());
            fields[5].setText(profile.getDegree());
            fields[6].setText(profile.getFieldOfSpecialization());
            fields[7].setText(profile.getAcademicInterests());
            fields[8].setText(profile.getProfessionalInterests());
            fields[9].setText(profile.getHobbies());
            fields[10].setText(profile.getCity());
            fields[11].setText(profile.getLanguages());
            fields[12].setText(profile.getWorkExperience());
            fields[13].setText(profile.getCareerAspirations());
            fields[14].setText(profile.getExtracurricularActivities());
            fields[15].setText(profile.getConversationProfile());
        }
        add(form, BorderLayout.CENTER);
        JButton saveBtn = new JButton("Save");
        saveBtn.addActionListener(e -> {
            saved = true;
            this.profile = new Profile();
            this.profile.setFullName(fields[0].getText());
            this.profile.setAge(Integer.parseInt(fields[1].getText()));
            this.profile.setSchool(fields[2].getText());
            this.profile.setCollege(fields[3].getText());
            this.profile.setAcademicQualification(fields[4].getText());
            this.profile.setDegree(fields[5].getText());
            this.profile.setFieldOfSpecialization(fields[6].getText());
            this.profile.setAcademicInterests(fields[7].getText());
            this.profile.setProfessionalInterests(fields[8].getText());
            this.profile.setHobbies(fields[9].getText());
            this.profile.setCity(fields[10].getText());
            this.profile.setLanguages(fields[11].getText());
            this.profile.setWorkExperience(fields[12].getText());
            this.profile.setCareerAspirations(fields[13].getText());
            this.profile.setExtracurricularActivities(fields[14].getText());
            this.profile.setConversationProfile(fields[15].getText());
            dispose();
        });
        add(saveBtn, BorderLayout.SOUTH);
    }

    public boolean isSaved() {
        return saved;
    }

    public Profile getProfile() {
        return profile;
    }
}
