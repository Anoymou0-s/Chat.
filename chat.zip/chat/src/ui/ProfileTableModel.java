package ui;

import model.Profile;
import javax.swing.table.AbstractTableModel;
import java.util.List;

public class ProfileTableModel extends AbstractTableModel {
    private List<Profile> profiles;
    private final String[] columns = {"ID", "Full Name", "Age", "School", "College", "Academic Qualification", "Degree", "Specialization", "Academic Interests", "Professional Interests", "Hobbies", "City", "Languages", "Work Experience", "Career Aspirations", "Extracurricular Activities", "Conversation Profile"};

    public ProfileTableModel(List<Profile> profiles) {
        this.profiles = profiles;
    }

    public void setProfiles(List<Profile> profiles) {
        this.profiles = profiles;
    }

    public Profile getProfileAt(int row) {
        return profiles.get(row);
    }

    @Override
    public int getRowCount() {
        return profiles.size();
    }

    @Override
    public int getColumnCount() {
        return columns.length;
    }

    @Override
    public String getColumnName(int col) {
        return columns[col];
    }

    @Override
    public Object getValueAt(int row, int col) {
        Profile p = profiles.get(row);
        switch (col) {
            case 0: return p.getId();
            case 1: return p.getFullName();
            case 2: return p.getAge();
            case 3: return p.getSchool();
            case 4: return p.getCollege();
            case 5: return p.getAcademicQualification();
            case 6: return p.getDegree();
            case 7: return p.getFieldOfSpecialization();
            case 8: return p.getAcademicInterests();
            case 9: return p.getProfessionalInterests();
            case 10: return p.getHobbies();
            case 11: return p.getCity();
            case 12: return p.getLanguages();
            case 13: return p.getWorkExperience();
            case 14: return p.getCareerAspirations();
            case 15: return p.getExtracurricularActivities();
            case 16: return p.getConversationProfile();
            default: return null;
        }
    }
}
