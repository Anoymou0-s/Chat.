package ui;

import model.Profile;
import service.ProfileService;
import dao.ProfileDaoImpl;
import database.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.util.List;

public class ProfileManagerUI extends JFrame {
    private ProfileService profileService;
    private JTable profileTable;
    private ProfileTableModel tableModel;

    public ProfileManagerUI() {
        setTitle("Profile Manager");
        setSize(900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        try {
            Connection conn = DatabaseConnection.getConnection();
            profileService = new ProfileService(new ProfileDaoImpl(conn));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database connection failed: " + e.getMessage());
            System.exit(1);
        }
        initUI();
    }

    private void initUI() {
        tableModel = new ProfileTableModel(profileService.getAllProfiles());
        profileTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(profileTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton addBtn = new JButton("Add Profile");
        JButton editBtn = new JButton("Edit Profile");
        JButton deleteBtn = new JButton("Delete Profile");
        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> openProfileDialog(null));
        editBtn.addActionListener(e -> {
            int row = profileTable.getSelectedRow();
            if (row >= 0) {
                Profile p = tableModel.getProfileAt(row);
                openProfileDialog(p);
            }
        });
        deleteBtn.addActionListener(e -> {
            int row = profileTable.getSelectedRow();
            if (row >= 0) {
                Profile p = tableModel.getProfileAt(row);
                profileService.deleteProfile(p.getId());
                refreshTable();
            }
        });
    }

    private void openProfileDialog(Profile profile) {
        ProfileDialog dialog = new ProfileDialog(this, profile);
        dialog.setVisible(true);
        if (dialog.isSaved()) {
            Profile p = dialog.getProfile();
            if (profile == null) {
                profileService.addProfile(p);
            } else {
                profileService.updateProfile(p);
            }
            refreshTable();
        }
    }

    private void refreshTable() {
        tableModel.setProfiles(profileService.getAllProfiles());
        tableModel.fireTableDataChanged();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProfileManagerUI().setVisible(true));
    }
}
