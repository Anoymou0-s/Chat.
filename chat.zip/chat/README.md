# Java Swing Profile Management Application

This application allows users to add, update, and delete profiles, each containing detailed academic, professional, and personal information, as well as a short conversation profile. Data is stored in an SQL database using JDBC.

## Features
- Add, update, and delete profiles
- Each profile includes:
  - Full name
  - Age
  - School
  - College/University
  - Academic qualification
  - Degree
  - Field of specialization
  - Academic interests
  - Professional interests
  - Hobbies/personal interests
  - City/town
  - Languages spoken
  - Work experience/internships
  - Career aspirations
  - Extracurricular activities
  - Short conversation profile (1 to a few words)

## How to Run
1. Ensure you have Java (JDK 8+) installed.
2. Set up your SQL database and update the JDBC connection details in the code.
3. Compile and run the application:
   ```
   javac -d bin src/**/*.java
   java -cp bin;path/to/jdbc/driver.jar Main
   ```

## Project Structure
- `src/model` - Data models
- `src/dao` - Database access objects
- `src/service` - Business logic
- `src/ui` - Swing UI components

## Requirements
- Java JDK 8 or higher
- JDBC driver for your database (e.g., MySQL, SQLite)

---
