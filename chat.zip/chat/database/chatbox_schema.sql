-- SQL schema for the profile management application
CREATE TABLE profile (
    id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100) NOT NULL,
    age INT,
    school VARCHAR(100),
    college VARCHAR(100),
    academic_qualification VARCHAR(100),
    degree VARCHAR(100),
    field_of_specialization VARCHAR(100),
    academic_interests VARCHAR(255),
    professional_interests VARCHAR(255),
    hobbies VARCHAR(255),
    city VARCHAR(100),
    languages VARCHAR(100),
    work_experience VARCHAR(255),
    career_aspirations VARCHAR(255),
    extracurricular_activities VARCHAR(255),
    conversation_profile VARCHAR(50)
);
