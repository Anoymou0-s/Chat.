-- Sample data for 3 profiles
INSERT INTO profile (
    full_name, age, school, college, academic_qualification, degree, field_of_specialization,
    academic_interests, professional_interests, hobbies, city, languages, work_experience,
    career_aspirations, extracurricular_activities, conversation_profile
) VALUES (
    'Aarav Sharma', 21, 'Delhi Public School', 'IIT Delhi', 'Undergraduate', 'B.Tech', 'Computer Science',
    'Artificial Intelligence, Algorithms', 'Software Development, Research', 'Reading, Chess, Coding', 'New Delhi',
    'Hindi, English', 'Intern at Google', 'Become a tech entrepreneur', 'Robotics Club, Debate Team', 'Innovator'
),
(
    'Meera Patel', 23, 'St. Xavier''s High School', 'Mumbai University', 'Postgraduate', 'M.Sc', 'Biotechnology',
    'Genetics, Molecular Biology', 'Pharmaceutical Research', 'Painting, Music, Yoga', 'Mumbai',
    'Gujarati, Hindi, English', 'Intern at Cipla', 'Lead a research team', 'Music Society, Art Club', 'Curious'
),
(
    'Rohan Verma', 20, 'La Martiniere', 'IISc Bangalore', 'Undergraduate', 'B.Sc', 'Physics',
    'Quantum Mechanics, Astrophysics', 'Academia, Data Science', 'Football, Astronomy, Gaming', 'Bangalore',
    'English, Kannada', 'Intern at ISRO', 'Become a scientist', 'Football Team, Science Club', 'Explorer'
);
